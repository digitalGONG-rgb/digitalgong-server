# 🚀 digitalGONG Server – Deployment Guide

## Schritt 1: Railway Account erstellen
1. Gehe zu https://railway.app
2. Klicke "Start a New Project"
3. Melde dich mit GitHub an (kostenlos)

## Schritt 2: GitHub Repository erstellen
1. Gehe zu https://github.com
2. Erstelle ein neues Repository: "digitalgong-server"
3. Lade alle Server-Dateien hoch

## Schritt 3: Auf Railway deployen
1. In Railway: "New Project" → "Deploy from GitHub repo"
2. Wähle "digitalgong-server"
3. Railway deployt automatisch!

## Schritt 4: Environment Variables setzen
In Railway → dein Projekt → "Variables":

```
PORT=4000
JWT_SECRET=digitalgong_dein_geheimer_key_2024
EMAIL_USER=deine.email@gmail.com
EMAIL_PASS=dein_gmail_app_passwort
```

### Gmail App Password erstellen:
1. Google Account → Security
2. 2-Step Verification aktivieren
3. App Passwords → "Mail" → Generate
4. Den 16-stelligen Code kopieren → EMAIL_PASS

## Schritt 5: Server URL bekommen
Railway gibt dir eine URL wie:
`https://digitalgong-server-production.up.railway.app`

## Schritt 6: App aktualisieren
In der App, Datei: `src/Network/Urls.ts`

```typescript
// ALT (fremder Server):
export const BASE_URL = "http://congnitix.crunchyapps.com:4000/api/"

// NEU (dein Server):
export const BASE_URL = "https://digitalgong-server-production.up.railway.app/api/"
```

## API Endpoints Übersicht

### Auth
| Method | URL | Beschreibung |
|--------|-----|-------------|
| POST | /api/users/account-setup | Registrieren |
| POST | /api/users/login | Einloggen |
| POST | /api/users/forgotPassword | OTP anfordern |
| POST | /api/users/verify-otp | OTP bestätigen |
| POST | /api/users/resetPassword | Passwort reset |
| POST | /api/users/user_data | User-Daten laden |
| POST | /api/users/Logout | Ausloggen |

### Doorbell (Klingel)
| Method | URL | Beschreibung |
|--------|-----|-------------|
| POST | /api/doorbell/register-device | Gerät registrieren |
| POST | /api/doorbell/ring | Klingel gedrückt (von Hardware) |
| POST | /api/doorbell/update-display | Display-Text ändern |
| GET | /api/doorbell/display/:id | Display-Text lesen (Hardware) |
| GET | /api/doorbell/my-devices | Meine Geräte |
| GET | /api/doorbell/sessions | Klingel-History |

## Hardware Integration (ATmega → ESP32)
Für die Hardware brauchst du ein WiFi-Modul (ESP8266 oder ESP32).
Wenn jemand klingelt, sendet das Modul:
```
POST /api/doorbell/ring
Body: { "deviceId": "xxx", "deviceSecret": "yyy" }
```
Der Server schickt dann eine E-Mail an den Bewohner.

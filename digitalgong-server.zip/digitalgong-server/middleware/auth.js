const jwt = require('jsonwebtoken')

const authMiddleware = (req, res, next) => {
  const authHeader = req.headers['authorization']
  
  if (!authHeader) {
    return res.status(401).json({ resultCode: 1, message: 'No token provided' })
  }

  const token = authHeader.replace('Bearer ', '')

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'digitalgong_secret_key_2024')
    req.user = decoded
    next()
  } catch (error) {
    return res.status(401).json({ resultCode: 2, message: 'Invalid token' })
  }
}

module.exports = authMiddleware

const express = require('express')
const router = express.Router()
const { devices, sessions, users } = require('../utils/db')
const { sendDoorbellNotificationEmail } = require('../utils/email')
const authMiddleware = require('../middleware/auth')
const { v4: uuidv4 } = require('uuid')

// ─── POST /api/doorbell/ring ──────────────────────────────────────────
// Called by the ATmega/ESP32 hardware when button is pressed
// Body: { deviceId, deviceSecret }
router.post('/ring', async (req, res) => {
  try {
    const { deviceId, deviceSecret } = req.body

    const device = devices.get(deviceId)
    if (!device) {
      return res.json({ resultCode: 1, message: 'Device not registered' })
    }

    if (device.secret !== deviceSecret) {
      return res.json({ resultCode: 1, message: 'Invalid device secret' })
    }

    // Create session
    const sessionId = uuidv4()
    sessions.set(sessionId, {
      sessionId,
      deviceId,
      deviceName: device.name,
      userId: device.userId,
      status: 'ringing',
      createdAt: Date.now(),
    })

    // Find owner and send email notification (until FCM is set up)
    const owner = users.get(device.userId)
    if (owner) {
      await sendDoorbellNotificationEmail(owner.email, device.name)
      console.log(`🔔 Doorbell ring: device ${device.name} → user ${owner.email}`)
    }

    return res.json({
      resultCode: 0,
      message: 'Ring registered',
      data: { sessionId }
    })
  } catch (error) {
    console.error('Ring error:', error)
    return res.json({ resultCode: 1, message: 'Server error' })
  }
})

// ─── POST /api/doorbell/register-device ──────────────────────────────
// App calls this after Bluetooth pairing to register the device to user
router.post('/register-device', authMiddleware, (req, res) => {
  try {
    const { deviceId, deviceName, bluetoothId } = req.body
    const secret = uuidv4().replace(/-/g, '').substring(0, 16)

    const device = {
      deviceId: deviceId || uuidv4(),
      name: deviceName || 'My digitalGONG',
      bluetoothId,
      userId: req.user.userid,
      secret,
      registeredAt: new Date().toISOString(),
    }

    devices.set(device.deviceId, device)
    console.log(`📱 Device registered: ${device.name} for user ${req.user.userid}`)

    return res.json({
      resultCode: 0,
      message: 'Device registered successfully',
      data: {
        deviceId: device.deviceId,
        deviceSecret: secret,
        deviceName: device.name,
      }
    })
  } catch (error) {
    return res.json({ resultCode: 1, message: 'Server error' })
  }
})

// ─── GET /api/doorbell/my-devices ────────────────────────────────────
router.get('/my-devices', authMiddleware, (req, res) => {
  const myDevices = Array.from(devices.values())
    .filter(d => d.userId === req.user.userid)
    .map(({ secret: _, ...d }) => d) // hide secret

  return res.json({ resultCode: 0, message: 'Success', data: myDevices })
})

// ─── GET /api/doorbell/sessions ──────────────────────────────────────
// App polls this to check for missed calls
router.get('/sessions', authMiddleware, (req, res) => {
  const myDeviceIds = Array.from(devices.values())
    .filter(d => d.userId === req.user.userid)
    .map(d => d.deviceId)

  const mySessions = Array.from(sessions.values())
    .filter(s => myDeviceIds.includes(s.deviceId))
    .sort((a, b) => b.createdAt - a.createdAt)
    .slice(0, 20)

  return res.json({ resultCode: 0, message: 'Success', data: mySessions })
})

// ─── POST /api/doorbell/update-display ───────────────────────────────
// App sends new name to display on TFT screen
router.post('/update-display', authMiddleware, (req, res) => {
  const { deviceId, displayName, subText } = req.body
  const device = devices.get(deviceId)

  if (!device || device.userId !== req.user.userid) {
    return res.json({ resultCode: 1, message: 'Device not found' })
  }

  device.displayName = displayName
  device.subText = subText
  devices.set(deviceId, device)

  console.log(`🖥️ Display update: "${displayName}" for device ${deviceId}`)

  return res.json({
    resultCode: 0,
    message: 'Display updated. Device will sync on next poll.',
    data: { displayName, subText }
  })
})

// ─── GET /api/doorbell/display/:deviceId ─────────────────────────────
// Hardware polls this to get current display text
router.get('/display/:deviceId', (req, res) => {
  const device = devices.get(req.params.deviceId)
  if (!device) {
    return res.json({ resultCode: 1, message: 'Device not found' })
  }

  return res.json({
    resultCode: 0,
    data: {
      displayName: device.displayName || 'digitalGONG',
      subText: device.subText || '',
    }
  })
})

module.exports = router

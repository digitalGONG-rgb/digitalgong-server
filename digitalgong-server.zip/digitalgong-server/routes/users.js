const express = require('express')
const router = express.Router()
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')
const { v4: uuidv4 } = require('uuid')
const { users, otpCodes } = require('../utils/db')
const { sendOtpEmail } = require('../utils/email')
const authMiddleware = require('../middleware/auth')

const JWT_SECRET = process.env.JWT_SECRET || 'digitalgong_secret_key_2024'

// ─── Generate 4-digit OTP ────────────────────────────────────────────
const generateOTP = () => Math.floor(1000 + Math.random() * 9000).toString()

// ─── POST /api/users/account-setup  (Register) ───────────────────────
// App sends: { fullName, userName, email, password, userType }
router.post('/account-setup', async (req, res) => {
  try {
    const { fullName, userName, email, password, userType } = req.body

    if (!fullName || !userName || !email || !password) {
      return res.json({ resultCode: 1, message: 'All fields are required' })
    }

    // Check if email already exists
    const existingUser = Array.from(users.values()).find(u => u.email === email.toLowerCase())
    if (existingUser) {
      return res.json({ resultCode: 1, message: 'Email already registered' })
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10)

    const userId = uuidv4()
    const newUser = {
      userid: userId,
      fullName,
      userName,
      email: email.toLowerCase(),
      password: hashedPassword,
      userType: userType || 'PRIVATE',
      createdAt: new Date().toISOString(),
      isVerified: false,
    }

    users.set(userId, newUser)

    // Generate OTP and send email
    const otp = generateOTP()
    otpCodes.set(email.toLowerCase(), {
      otp,
      expiresAt: Date.now() + 10 * 60 * 1000, // 10 minutes
      userId
    })

    console.log(`📧 OTP for ${email}: ${otp}`) // visible in server logs
    await sendOtpEmail(email, otp)

    const token = jwt.sign({ userid: userId, email: newUser.email }, JWT_SECRET, { expiresIn: '7d' })

    return res.json({
      resultCode: 0,
      message: 'Registration successful. OTP sent to your email.',
      data: {
        userid: userId,
        fullName,
        userName,
        email: newUser.email,
        userType: newUser.userType,
        token,
      }
    })
  } catch (error) {
    console.error('Register error:', error)
    return res.json({ resultCode: 1, message: 'Server error' })
  }
})

// ─── POST /api/users/login ───────────────────────────────────────────
// App sends: { email, password }
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body

    if (!email || !password) {
      return res.json({ resultCode: 1, message: 'Email and password required' })
    }

    const user = Array.from(users.values()).find(u => u.email === email.toLowerCase())

    if (!user) {
      return res.json({ resultCode: 1, message: 'User not found. Please register first.' })
    }

    const isMatch = await bcrypt.compare(password, user.password)
    if (!isMatch) {
      return res.json({ resultCode: 1, message: 'Invalid credentials' })
    }

    const token = jwt.sign({ userid: user.userid, email: user.email }, JWT_SECRET, { expiresIn: '7d' })

    return res.json({
      resultCode: 0,
      message: 'Login successful',
      data: {
        userid: user.userid,
        fullName: user.fullName,
        userName: user.userName,
        email: user.email,
        userType: user.userType,
        token,
      }
    })
  } catch (error) {
    console.error('Login error:', error)
    return res.json({ resultCode: 1, message: 'Server error' })
  }
})

// ─── POST /api/users/user_data ───────────────────────────────────────
router.post('/user_data', authMiddleware, (req, res) => {
  const user = users.get(req.user.userid)
  if (!user) return res.json({ resultCode: 1, message: 'User not found' })

  const { password: _, ...safeUser } = user
  return res.json({ resultCode: 0, message: 'Success', data: safeUser })
})

// ─── POST /api/users/forgotPassword ─────────────────────────────────
router.post('/forgotPassword', async (req, res) => {
  try {
    const { email } = req.body
    const user = Array.from(users.values()).find(u => u.email === email?.toLowerCase())

    if (!user) {
      return res.json({ resultCode: 1, message: 'Email not found' })
    }

    const otp = generateOTP()
    otpCodes.set(email.toLowerCase(), {
      otp,
      expiresAt: Date.now() + 10 * 60 * 1000,
      userId: user.userid,
      type: 'reset'
    })

    console.log(`🔑 Reset OTP for ${email}: ${otp}`)
    await sendOtpEmail(email, otp)

    return res.json({ resultCode: 0, message: 'OTP sent to your email' })
  } catch (error) {
    return res.json({ resultCode: 1, message: 'Server error' })
  }
})

// ─── POST /api/users/verify-otp ──────────────────────────────────────
router.post('/verify-otp', (req, res) => {
  const { email, otp } = req.body
  const stored = otpCodes.get(email?.toLowerCase())

  if (!stored) return res.json({ resultCode: 1, message: 'OTP not found or expired' })
  if (Date.now() > stored.expiresAt) {
    otpCodes.delete(email.toLowerCase())
    return res.json({ resultCode: 1, message: 'OTP expired. Please request a new one.' })
  }
  if (stored.otp !== otp) {
    return res.json({ resultCode: 1, message: 'Invalid OTP' })
  }

  // Mark user as verified
  const user = users.get(stored.userId)
  if (user) {
    user.isVerified = true
    users.set(user.userid, user)
  }

  otpCodes.delete(email.toLowerCase())
  return res.json({ resultCode: 0, message: 'OTP verified successfully' })
})

// ─── POST /api/users/resetPassword ───────────────────────────────────
router.post('/resetPassword', async (req, res) => {
  try {
    const { email, newPassword } = req.body
    const user = Array.from(users.values()).find(u => u.email === email?.toLowerCase())

    if (!user) return res.json({ resultCode: 1, message: 'User not found' })

    user.password = await bcrypt.hash(newPassword, 10)
    users.set(user.userid, user)

    return res.json({ resultCode: 0, message: 'Password reset successful' })
  } catch (error) {
    return res.json({ resultCode: 1, message: 'Server error' })
  }
})

// ─── POST /api/users/updateProfile ───────────────────────────────────
router.post('/updateProfile', authMiddleware, async (req, res) => {
  const user = users.get(req.user.userid)
  if (!user) return res.json({ resultCode: 1, message: 'User not found' })

  const { fullName, userName } = req.body
  if (fullName) user.fullName = fullName
  if (userName) user.userName = userName
  users.set(user.userid, user)

  const { password: _, ...safeUser } = user
  return res.json({ resultCode: 0, message: 'Profile updated', data: safeUser })
})

// ─── POST /api/users/Logout ───────────────────────────────────────────
router.post('/Logout', authMiddleware, (req, res) => {
  return res.json({ resultCode: 0, message: 'Logged out successfully' })
})

// ─── POST /api/users/RefreshToken ────────────────────────────────────
router.post('/RefreshToken', (req, res) => {
  const { token } = req.body
  try {
    const decoded = jwt.verify(token, JWT_SECRET)
    const newToken = jwt.sign({ userid: decoded.userid, email: decoded.email }, JWT_SECRET, { expiresIn: '7d' })
    return res.json({ resultCode: 0, message: 'Token refreshed', data: { token: newToken } })
  } catch {
    return res.json({ resultCode: 2, message: 'Invalid token' })
  }
})

// ─── POST /api/users/process_user_input ──────────────────────────────
// Used for updating display name on doorbell device
router.post('/process_user_input', authMiddleware, (req, res) => {
  const { displayName, deviceId } = req.body
  console.log(`Display name update: ${displayName} for device ${deviceId}`)
  return res.json({ resultCode: 0, message: 'Display name updated', data: { displayName, deviceId } })
})

// ─── POST /api/users/invite_user ─────────────────────────────────────
router.post('/invite_user', authMiddleware, (req, res) => {
  return res.json({ resultCode: 0, message: 'Invitation sent' })
})

// ─── POST /api/users/family_members ──────────────────────────────────
router.post('/family_members', authMiddleware, (req, res) => {
  return res.json({ resultCode: 0, message: 'Success', data: [] })
})

// ─── POST /api/users/remove_user ────────────────────────────────────
router.post('/remove_user', authMiddleware, (req, res) => {
  return res.json({ resultCode: 0, message: 'User removed' })
})

// ─── POST /api/users/update_billing ─────────────────────────────────
router.post('/update_billing', authMiddleware, (req, res) => {
  return res.json({ resultCode: 0, message: 'Billing updated' })
})

// ─── POST /api/users/invitation_accept_reject ───────────────────────
router.post('/invitation_accept_reject', authMiddleware, (req, res) => {
  return res.json({ resultCode: 0, message: 'Invitation updated' })
})

module.exports = router

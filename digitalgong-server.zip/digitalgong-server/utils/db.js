// Simple in-memory database
// Later you can replace this with PostgreSQL or MongoDB

const users = new Map()
const otpCodes = new Map()
const devices = new Map()  // doorbell devices
const sessions = new Map() // active doorbell sessions

module.exports = { users, otpCodes, devices, sessions }

const nodemailer = require('nodemailer')

const sendOtpEmail = async (toEmail, otp) => {
  // Use Gmail - you need to set EMAIL_USER and EMAIL_PASS in .env
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS, // Gmail App Password (not your normal password)
    },
  })

  const mailOptions = {
    from: `"digitalGONG" <${process.env.EMAIL_USER}>`,
    to: toEmail,
    subject: 'digitalGONG - Your OTP Code',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 400px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #4A0080, #1a1a4e); padding: 30px; border-radius: 16px; text-align: center;">
          <h1 style="color: white; margin: 0;">🔔 digitalGONG</h1>
          <p style="color: rgba(255,255,255,0.7); font-size: 14px;">the smart doorbell system</p>
        </div>
        <div style="padding: 30px; background: #f9f9f9; border-radius: 0 0 16px 16px;">
          <h2 style="color: #333;">Your OTP Code</h2>
          <p style="color: #666;">Use this code to verify your account:</p>
          <div style="background: linear-gradient(135deg, #A42172, #4A0080); padding: 20px; border-radius: 12px; text-align: center; margin: 20px 0;">
            <span style="color: white; font-size: 36px; font-weight: bold; letter-spacing: 8px;">${otp}</span>
          </div>
          <p style="color: #999; font-size: 12px;">This code expires in 10 minutes. Do not share it with anyone.</p>
        </div>
      </div>
    `,
  }

  try {
    await transporter.sendMail(mailOptions)
    console.log(`OTP sent to ${toEmail}`)
    return true
  } catch (error) {
    console.error('Email send error:', error.message)
    return false
  }
}

const sendDoorbellNotificationEmail = async (toEmail, deviceName) => {
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS,
    },
  })

  const mailOptions = {
    from: `"digitalGONG" <${process.env.EMAIL_USER}>`,
    to: toEmail,
    subject: '🔔 Someone is at your door!',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 400px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #4A0080, #1a1a4e); padding: 30px; border-radius: 16px; text-align: center;">
          <h1 style="color: white; margin: 0;">🔔 digitalGONG</h1>
        </div>
        <div style="padding: 30px; background: #f9f9f9;">
          <h2>Someone rang your doorbell!</h2>
          <p>Device: <strong>${deviceName}</strong></p>
          <p>Open the digitalGONG app to see who is there.</p>
        </div>
      </div>
    `,
  }

  try {
    await transporter.sendMail(mailOptions)
    return true
  } catch (error) {
    console.error('Notification email error:', error.message)
    return false
  }
}

module.exports = { sendOtpEmail, sendDoorbellNotificationEmail }
